const express = require('express');
const cors = require('cors');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');

const { User, Product, CartItem, Order } = require('./database');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- Authentication ---
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ username, password });
        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        res.json({ user: { id: user._id, username: user.username, role: user.role } });
    } catch (err) {
        console.error("Login error:", err);
        res.status(500).json({ error: 'Server error' });
    }
});

// --- Products ---
app.get('/api/products', async (req, res) => {
    try {
        const products = await Product.find();
        const rows = products.map(p => ({
            id: p._id,
            name: p.name,
            price: p.price,
            image: p.image,
            description: p.description
        }));
        res.json(rows);
    } catch (err) {
        console.error("Error reading products:", err);
        res.status(500).json({ error: 'Failed to load products' });
    }
});

app.post('/api/products', async (req, res) => {
    try {
        const { name, price, image, description } = req.body;
        const product = await Product.create({ name, price, image, description });
        
        const newProduct = { 
            id: product._id, 
            name: product.name, 
            price: product.price, 
            image: product.image, 
            description: product.description 
        };
        
        // Emit event to all connected clients
        io.emit('product_added', newProduct);
        res.status(201).json(newProduct);
    } catch (err) {
        console.error("Error adding product:", err);
        res.status(500).json({ error: 'Failed to add product' });
    }
});

// --- Cart ---
app.get('/api/cart/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const cartItems = await CartItem.find({ user_id: userId }).populate('product_id');
        
        const rows = cartItems.map(c => {
            if (!c.product_id) return null;
            return {
                cart_item_id: c._id,
                quantity: c.quantity,
                id: c.product_id._id,
                name: c.product_id.name,
                price: c.product_id.price,
                image: c.product_id.image,
                description: c.product_id.description
            };
        }).filter(item => item !== null);
        
        res.json(rows);
    } catch (err) {
        console.error("Error loading cart:", err);
        res.status(500).json({ error: 'Failed to load cart' });
    }
});

app.post('/api/cart/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const { productId, quantity } = req.body;

        let cartItem = await CartItem.findOne({ user_id: userId, product_id: productId });
        
        if (cartItem) {
            // Update quantity
            const newQty = cartItem.quantity + (quantity || 1);
            cartItem.quantity = newQty;
            await cartItem.save();
            res.json({ success: true, updatedItemId: cartItem._id, quantity: newQty });
        } else {
            // Insert new item
            const qty = quantity || 1;
            cartItem = await CartItem.create({ user_id: userId, product_id: productId, quantity: qty });
            res.json({ success: true, newCartItemId: cartItem._id, quantity: qty });
        }
    } catch (err) {
        console.error("Error modifying cart:", err);
        res.status(500).json({ error: 'Failed to modify cart' });
    }
});

app.put('/api/cart/:userId/:productId', async (req, res) => {
    try {
        const { userId, productId } = req.params;
        const { quantity } = req.body;
        
        await CartItem.findOneAndUpdate(
            { user_id: userId, product_id: productId },
            { quantity }
        );
        res.json({ success: true });
    } catch (err) {
        console.error("Error updating cart quantity:", err);
        res.status(500).json({ error: 'Failed to update quantity' });
    }
});

app.delete('/api/cart/:userId/:productId', async (req, res) => {
    try {
        const { userId, productId } = req.params;
        await CartItem.deleteOne({ user_id: userId, product_id: productId });
        res.json({ success: true });
    } catch (err) {
        console.error("Error removing cart item:", err);
        res.status(500).json({ error: 'Failed to remove item' });
    }
});

// --- Checkout ---
app.post('/api/checkout/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        const cartItems = await CartItem.find({ user_id: userId }).populate('product_id');
        
        if (cartItems.length === 0) {
            return res.status(400).json({ error: 'Cart is empty' });
        }

        let totalAmount = 0;
        const orderItems = cartItems.map(c => {
            const price = c.product_id ? c.product_id.price : 0;
            const name = c.product_id ? c.product_id.name : 'Unknown Product';
            totalAmount += price * c.quantity;
            return {
                product_id: c.product_id ? c.product_id._id : null,
                name: name,
                price: price,
                quantity: c.quantity
            };
        });

        const order = await Order.create({
            user_id: userId,
            items: orderItems,
            totalAmount: totalAmount
        });

        // Clear user's cart
        await CartItem.deleteMany({ user_id: userId });

        res.json({ success: true, orderId: order._id });
    } catch (err) {
        console.error("Error creating order:", err);
        res.status(500).json({ error: 'Failed to checkout' });
    }
});

// --- Socket.io ---
io.on('connection', (socket) => {
    console.log('A user connected:', socket.id);
    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
    });
});

// Start the server
server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
