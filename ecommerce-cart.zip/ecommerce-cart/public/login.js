const loginForm = document.getElementById('login-form');
const errorMsg = document.getElementById('login-error');

// Redirect if already logged in
window.addEventListener('DOMContentLoaded', () => {
    const user = localStorage.getItem('lumina_user');
    if (user) {
        const parsed = JSON.parse(user);
        if (parsed.role === 'seller') {
            window.location.href = 'seller.html';
        } else {
            window.location.href = 'index.html';
        }
    }
});

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorMsg.style.display = 'none';

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        if (!response.ok) {
            throw new Error('Login failed');
        }

        const data = await response.json();

        // Save user to local storage
        localStorage.setItem('lumina_user', JSON.stringify(data.user));

        // Redirect based on role
        if (data.user.role === 'seller') {
            window.location.href = 'seller.html';
        } else {
            window.location.href = 'index.html';
        }

    } catch (error) {
        console.error('Login error:', error);
        errorMsg.style.display = 'block';
    }
});
