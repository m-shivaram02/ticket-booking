const sellerName = document.getElementById('seller-name');
const logoutBtn = document.getElementById('logout-btn');
const productForm = document.getElementById('add-product-form');
const successMsg = document.getElementById('success-msg');
const productsGrid = document.getElementById('seller-products-grid');

let user = null;
let products = [];

// Initialize
function init() {
    checkAuth();
    sellerName.textContent = `Welcome, ${user.username}`;
    fetchProducts();
}

// Authentication Check
function checkAuth() {
    const userStr = localStorage.getItem('lumina_user');
    if (!userStr) {
        window.location.href = 'login.html';
        return;
    }
    user = JSON.parse(userStr);
    if (user.role !== 'seller') {
        window.location.href = 'index.html'; // Redirect buyers
    }
}

// Logout
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('lumina_user');
    window.location.href = 'login.html';
});

// Fetch all products
async function fetchProducts() {
    try {
        const res = await fetch('/api/products');
        products = await res.json();
        renderProducts();
    } catch (err) {
        console.error("Failed to load products", err);
    }
}

// Render products in grid
function renderProducts() {
    if (products.length === 0) {
        productsGrid.innerHTML = '<p>No products available.</p>';
        return;
    }

    productsGrid.innerHTML = products.map(p => `
        <article class="product-card">
            <img src="${p.image}" alt="${p.name}" class="product-image" loading="lazy">
            <div class="product-info">
                <h3 class="product-title">${p.name}</h3>
                <p class="product-price">$${p.price.toFixed(2)}</p>
            </div>
        </article>
    `).reverse().join(''); // Reverse to show newest first
}

// Add Product
productForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const newProduct = {
        name: document.getElementById('name').value,
        price: parseFloat(document.getElementById('price').value),
        image: document.getElementById('image').value,
        description: document.getElementById('description').value
    };

    try {
        const res = await fetch('/api/products', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newProduct)
        });

        if (res.ok) {
            const addedProduct = await res.json();
            products.push(addedProduct);
            renderProducts();

            // Reset form and show success
            productForm.reset();
            successMsg.style.display = 'inline';
            setTimeout(() => { successMsg.style.display = 'none'; }, 3000);
        } else {
            alert('Failed to add product');
        }
    } catch (err) {
        console.error(err);
        alert('Failed to connect to server.');
    }
});

init();
