// DOM Elements
const productsGrid = document.getElementById('products-grid');
const cartIcon = document.getElementById('cart-icon');
const cartOverlay = document.getElementById('cart-overlay');
const cartSidebar = document.getElementById('cart-sidebar');
const closeCartBtn = document.getElementById('close-cart');
const cartItemsContainer = document.getElementById('cart-items');
const cartCountElement = document.getElementById('cart-count');
const cartTotalPriceElement = document.getElementById('cart-total-price');
const checkoutBtn = document.getElementById('checkout-btn');
const toast = document.getElementById('toast');
const buyerNameEl = document.getElementById('buyer-name');
const logoutBtn = document.getElementById('logout-btn');

// State
let products = [];
let cart = [];
let user = null;

// Socket.io
const socket = io();

// Initialize
async function init() {
    checkAuth();
    buyerNameEl.textContent = `Hello, ${user.username}`;

    await fetchProducts();
    await fetchCart();

    // Setup real-time listeners
    setupSocketListeners();
}

// Auth checks
function checkAuth() {
    const userStr = localStorage.getItem('lumina_user');
    if (!userStr) {
        window.location.href = 'login.html';
        return;
    }
    user = JSON.parse(userStr);
}

// Logout
logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('lumina_user');
    window.location.href = 'login.html';
});

// Socket.io real-time listeners
function setupSocketListeners() {
    socket.on('product_added', (newProduct) => {
        // Add to local state
        products.push(newProduct);

        // Re-render
        renderProducts();

        // Optional: show a toast specific to new product
        toast.textContent = "New product available!";
        showToast();
        // Reset toast text
        setTimeout(() => toast.textContent = "Item added to cart!", 3000);
    });
}

// Fetch Products from API
async function fetchProducts() {
    try {
        const response = await fetch('/api/products');
        if (!response.ok) throw new Error('Failed to fetch products');
        products = await response.json();
        renderProducts();
    } catch (error) {
        console.error('Error:', error);
        productsGrid.innerHTML = `<div class="loading" style="color: var(--danger-color)">Failed to load products. Please try again later.</div>`;
    }
}

// Render Products to DOM
function renderProducts() {
    if (products.length === 0) {
        productsGrid.innerHTML = '<div class="loading">No products found.</div>';
        return;
    }

    productsGrid.innerHTML = products.map(product => `
        <article class="product-card">
            <img src="${product.image}" alt="${product.name}" class="product-image" loading="lazy">
            <div class="product-info">
                <h3 class="product-title">${product.name}</h3>
                <p class="product-desc">${product.description}</p>
                <div class="product-footer">
                    <span class="product-price">$${product.price.toFixed(2)}</span>
                    <button class="add-to-cart-btn" onclick="addToCart('${product.id}')" aria-label="Add to cart">
                        <i class="fa-solid fa-plus"></i>
                    </button>
                </div>
            </div>
        </article>
    `).reverse().join(''); // Reverse so newest are first
}

// --- Cart Logic (DB Persistent) ---

// Fetch cart from API
async function fetchCart() {
    try {
        const response = await fetch(`/api/cart/${user.id}`);
        if (!response.ok) throw new Error('Failed to fetch cart');
        cart = await response.json();
        renderCart();
    } catch (e) {
        console.error("Error fetching cart from DB", e);
    }
}

// Add item to cart
async function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    try {
        const res = await fetch(`/api/cart/${user.id}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ productId, quantity: 1 })
        });

        if (res.ok) {
            await fetchCart(); // Refresh from DB to ensure sync
            showToast();
        }
    } catch (err) {
        console.error('Error adding to db cart', err);
    }
}

// Remove item from cart
async function removeFromCart(productId) {
    try {
        const res = await fetch(`/api/cart/${user.id}/${productId}`, {
            method: 'DELETE'
        });
        if (res.ok) {
            await fetchCart();
        }
    } catch (err) {
        console.error('Error removing from db cart', err);
    }
}

// Update item quantity
async function updateQuantity(productId, newQuantity) {
    if (newQuantity < 1) return;

    try {
        const res = await fetch(`/api/cart/${user.id}/${productId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ quantity: newQuantity })
        });
        if (res.ok) {
            await fetchCart();
        }
    } catch (err) {
        console.error('Error updating db cart quantity', err);
    }
}

// Render cart UI
function renderCart() {
    // Calculate totals
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    // Update count badge
    cartCountElement.textContent = totalItems;

    // Update total price
    cartTotalPriceElement.textContent = `$${totalPrice.toFixed(2)}`;

    // Enable/disable checkout
    checkoutBtn.disabled = cart.length === 0;

    // Render items
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `
            <div class="empty-cart">
                <i class="fa-solid fa-basket-shopping"></i>
                <p>Your cart is empty</p>
            </div>
        `;
        return;
    }

    cartItemsContainer.innerHTML = cart.map(item => `
        <div class="cart-item">
            <img src="${item.image}" alt="${item.name}" class="cart-item-img">
            <div class="cart-item-details">
                <h4 class="cart-item-title">${item.name}</h4>
                <span class="cart-item-price">$${(item.price * item.quantity).toFixed(2)}</span>
                <div class="cart-item-actions">
                    <div class="quantity-controls">
                        <button class="qty-btn" onclick="updateQuantity('${item.id}', ${item.quantity - 1})" ${item.quantity <= 1 ? 'disabled' : ''}>-</button>
                        <input type="number" class="qty-input" value="${item.quantity}" readonly>
                        <button class="qty-btn" onclick="updateQuantity('${item.id}', ${item.quantity + 1})">+</button>
                    </div>
                    <button class="remove-btn" onclick="removeFromCart('${item.id}')">
                        <i class="fa-regular fa-trash-can"></i> Remove
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// --- UI Interactions ---

// Open Cart
function openCart() {
    cartOverlay.classList.add('active');
    cartSidebar.classList.add('active');
    document.body.style.overflow = 'hidden'; // Prevent background scrolling
}

// Close Cart
function closeCart() {
    cartOverlay.classList.remove('active');
    cartSidebar.classList.remove('active');
    document.body.style.overflow = '';
}

// Show Toast Notification
function showToast() {
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Event Listeners
cartIcon.addEventListener('click', openCart);
closeCartBtn.addEventListener('click', closeCart);
cartOverlay.addEventListener('click', closeCart);

// Handle checkout button
checkoutBtn.addEventListener('click', async () => {
    if (cart.length === 0) return;
    try {
        const res = await fetch(`/api/checkout/${user.id}`, { method: 'POST' });
        if (res.ok) {
            const data = await res.json();
            alert(`Order placed successfully!\nYour Order ID: ${data.orderId}`);
            await fetchCart(); // will re-render and empty the cart since it was deleted in DB
            closeCart();
        } else {
            alert('Checkout failed: Could not process order.');
        }
    } catch (err) {
        console.error('Checkout error:', err);
        alert('System error during checkout.');
    }
});

// Run initialization
init();
