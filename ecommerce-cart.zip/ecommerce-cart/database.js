const mongoose = require('mongoose');
const path = require('path');
const fs = require('fs');

mongoose.connect('mongodb://127.0.0.1:27017/ecommerce').then(() => {
    console.log('Connected to MongoDB database.');
    initDb();
}).catch(err => {
    console.error('Error connecting to MongoDB:', err.message);
});

// Schemas
const userSchema = new mongoose.Schema({
    username: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    role: { type: String, required: true }
});

const productSchema = new mongoose.Schema({
    name: String,
    price: Number,
    image: String,
    description: String
});

const cartItemSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    product_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
    quantity: { type: Number, default: 1 }
});

const orderSchema = new mongoose.Schema({
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    items: [{
        product_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
        name: String,
        price: Number,
        quantity: Number
    }],
    totalAmount: Number,
    date: { type: Date, default: Date.now }
});

const User = mongoose.model('User', userSchema);
const Product = mongoose.model('Product', productSchema);
const CartItem = mongoose.model('CartItem', cartItemSchema);
const Order = mongoose.model('Order', orderSchema);

async function initDb() {
    try {
        // Seed Users
        const userCount = await User.countDocuments();
        if (userCount === 0) {
            await User.create([
                { username: 'buyer', password: 'pwd', role: 'buyer' },
                { username: 'seller', password: 'pwd', role: 'seller' }
            ]);
            console.log("Seeded default users: 'buyer' / 'pwd' and 'seller' / 'pwd'");
        }

        // Seed Products
        const productCount = await Product.countDocuments();
        if (productCount === 0) {
            const productsPath = path.join(__dirname, 'data', 'products.json');
            if (fs.existsSync(productsPath)) {
                const productsList = JSON.parse(fs.readFileSync(productsPath, 'utf8'));
                await Product.insertMany(productsList);
                console.log("Seeded products from products.json.");
            }
        }
    } catch (err) {
        console.error("Error during database initialization:", err);
    }
}

module.exports = { User, Product, CartItem, Order };
