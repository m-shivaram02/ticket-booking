const API_URL = 'http://localhost:5000/api/auth';

document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  await handleAuth('/login');
});



async function handleAuth(endpoint) {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  if(!username || !password) {
    if(endpoint === '/register') {
      alert("CRITICAL: IDENTITY PARAMETERS MISSING.\n\nTo create a new identity, please enter your desired Operator ID and Passcode in the fields above, then click 'Create New Identity' again.");
    } else {
      alert("CRITICAL: IDENTITY PARAMETERS MISSING.");
    }
    return;
  }

  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();

    if (response.ok) {
      if (endpoint === '/login') {
        localStorage.setItem('cyber_token', data.token);
        localStorage.setItem('cyber_user', JSON.stringify(data.user));
        window.location.href = 'index.html';
      } else {
        alert("Identity Registered. Proceed to Initialize Login.");
      }
    } else {
      alert(`ACCESS DENIED: ${data.msg}`);
    }
  } catch(err) {
    alert("CONNECTION TO MAINFRAME FAILED.");
    console.error(err);
  }
}
