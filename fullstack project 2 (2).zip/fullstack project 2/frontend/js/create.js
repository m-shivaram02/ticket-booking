const API_URL = 'http://localhost:5000/api/events';

document.addEventListener('DOMContentLoaded', () => {
  if (!localStorage.getItem('cyber_token')) {
    window.location.href = 'login.html';
  }
});


document.getElementById('create-event-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const token = localStorage.getItem('cyber_token');
  
  const eventData = {
    title: document.getElementById('title').value,
    category: document.getElementById('category').value,
    date: document.getElementById('date').value,
    registrationDeadline: document.getElementById('registrationDeadline').value,
    location: document.getElementById('location').value,
    organizer: document.getElementById('organizer').value,
    description: document.getElementById('description').value,
  };

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': token ? `Bearer ${token}` : ''
      },
      body: JSON.stringify(eventData)
    });

    if (response.ok) {
      window.location.href = 'index.html';
    } else {
      const errorData = await response.json();
      alert(`SYSTEM FAILURE: ${errorData.msg || errorData.message || 'Server error'}`);
    }
  } catch (error) {
    alert('TRANSMISSION FAILED.');
  }
});
