const API_URL = 'http://localhost:5000/api/events';

document.addEventListener('DOMContentLoaded', () => {
  const userStr = localStorage.getItem('cyber_user');
  if (!userStr) {
    window.location.href = 'login.html';
    return;
  }
  const user = JSON.parse(userStr);
  if (user.role !== 'admin') {
    alert("ACCESS DENIED. ADMIN CLEARENCE REQUIRED.");
    window.location.href = 'index.html';
    return;
  }
  
  document.getElementById('auth-status').innerText = `Operator: ${user.username} [ACTIVE]`;

  initScanner();
});

let isScanning = true;

function initScanner() {
  const html5QrcodeScanner = new Html5QrcodeScanner(
    "reader",
    { fps: 10, qrbox: {width: 250, height: 250} },
    /* verbose= */ false);

  html5QrcodeScanner.render(onScanSuccess, onScanFailure);
  
  async function onScanSuccess(decodedText, decodedResult) {
    if (!isScanning) return;
    
    // Stop scanning temporarily while processing
    isScanning = false;
    const resultDiv = document.getElementById('scan-result');
    resultDiv.innerHTML = `<span style="color:var(--primary);">PROCESSING SIGNAL...</span>`;
    
    try {
      const data = JSON.parse(decodedText);
      if (!data.eventId || !data.userId) throw new Error("Invalid Format");
      
      const token = localStorage.getItem('cyber_token');
      const res = await fetch(`${API_URL}/${data.eventId}/checkin/${data.userId}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      
      const resData = await res.json();
      if (res.ok) {
        resultDiv.innerHTML = `<span style="color:lime;">[ VERIFIED: ACCESS GRANTED ]</span>`;
      } else {
        resultDiv.innerHTML = `<span style="color:red;">[ ERROR: ${resData.msg} ]</span>`;
      }
    } catch(e) {
      resultDiv.innerHTML = `<span style="color:red;">[ CRITICAL: INVALID QR SIGNATURE ]</span>`;
    }
    
    // Resume scanning after 3 seconds
    setTimeout(() => {
      isScanning = true;
      resultDiv.innerHTML = '[ WAITING FOR TICKET SCAN... ]';
    }, 3000);
  }

  function onScanFailure(error) {
    // handle scan failure, usually better to ignore and keep scanning
  }
}
