const API_URL = 'http://localhost:5000/api/events';
let allEventsData = [];

document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
  fetchEvents();
});

function checkAuth() {
  const userStr = localStorage.getItem('cyber_user');
  if (userStr) {
    const user = JSON.parse(userStr);
    document.getElementById('auth-status').innerText = `Operator: ${user.username} [ACTIVE]`;
    const link = document.getElementById('auth-link');
    link.innerText = '[ TERMINATE SESSION ]';
    link.href = '#';
    link.onclick = () => {
      localStorage.removeItem('cyber_token');
      localStorage.removeItem('cyber_user');
      window.location.reload();
    };
    if (user.role === 'admin') {
      const createBtn = document.getElementById('create-event-btn');
      if (createBtn) createBtn.style.display = 'inline-block';
      const checkinBtn = document.getElementById('checkin-btn');
      if (checkinBtn) checkinBtn.style.display = 'inline-block';
    }
  }
}

async function fetchEvents() {
  const container = document.getElementById('events-container');
  try {
    const response = await fetch(API_URL);
    allEventsData = await response.json();
    displayEventsList();
    initCalendar();
    initAnalytics();
  } catch (error) {
    container.innerHTML = `<div style="color:red;">CRITICAL ERROR: CONNECTION TO DATA STREAM FAILED.</div>`;
  }
}

function displayEventsList() {
  const container = document.getElementById('events-container');
  if (allEventsData.length === 0) {
    container.innerHTML = '<div>DATABASE EMPTY.</div>';
    return;
  }

  const currentUserStr = localStorage.getItem('cyber_user');
  const currentUserId = currentUserStr ? JSON.parse(currentUserStr).id : null;
  const currentUserRole = currentUserStr ? JSON.parse(currentUserStr).role : null;

  container.innerHTML = allEventsData.map(ev => {
    const deadline = new Date(ev.registrationDeadline);
    const hasPassed = new Date() > deadline;
    const attendeeRecord = ev.attendees.find(a => (a.user && a.user._id === currentUserId) || a.user === currentUserId || a._id === currentUserId || a === currentUserId);
    const isRegistered = !!attendeeRecord;
    const teamName = isRegistered && attendeeRecord.team ? attendeeRecord.team : '';
    const checkedInText = attendeeRecord && attendeeRecord.checkedIn ? '<span style="color:lime; font-weight:bold; margin-left:10px;">[VERIFIED]</span>' : '';

    let regBtn = '';
    if (hasPassed) {
      regBtn = `<button class="btn btn-secondary" disabled>REG TIME ELAPSED</button>`;
    } else if (isRegistered) {
      regBtn = `<button class="btn" style="border-color:var(--primary); color:var(--primary);" onclick="showTicket('${ev._id}')">SHOW TICKET</button>
                <button class="btn btn-secondary" style="margin-left:10px; border-color:orange; color:orange;" onclick="changeTeam('${ev._id}')">CHANGE TEAM</button>
                <button class="btn btn-secondary" style="margin-left:10px; border-color:orange; color:orange;" onclick="deregisterEvent('${ev._id}')">UNREGISTER</button>`;
    } else {
      regBtn = `<button class="btn" onclick="registerEvent('${ev._id}')">SECURE TICKET</button>`;
    }

    let delBtn = '';
    if (currentUserRole === 'admin') {
      delBtn = `<button class="btn btn-secondary" style="margin-left:10px; border-color:red; color:red;" onclick="deleteEvent('${ev._id}')">DELETE</button>`;
    }

    return `
      <div class="event-card">
        <div class="event-category">// ${ev.category}</div>
        <h3 class="event-title">${ev.title}</h3>
        <p class="event-desc">${ev.description}</p>
        <div class="event-meta"><i class="fas fa-clock"></i> Date: ${new Date(ev.date).toLocaleString()}</div>
        <div class="event-meta"><i class="fas fa-map-marker-alt"></i> Loc: ${ev.location}</div>
        <div class="deadline-warning">⚠ Deadline: ${deadline.toLocaleString()}</div>
        ${isRegistered ? `<div class="event-meta" style="color:var(--primary);"><i class="fas fa-users"></i> Team: ${teamName} ${checkedInText}</div>` : ''}
        <div style="margin-top:auto; display:flex; justify-content:space-between; align-items:flex-end;">
          <div>
            ${regBtn}
            ${delBtn}
          </div>
          <div style="font-size:0.8em; color:#fff;">[ ${ev.attendees.length} Attendees ]</div>
        </div>
      </div>
    `;
  }).join('');
}

async function registerEvent(id) {
  const token = localStorage.getItem('cyber_token');
  if (!token) {
    alert("AUTHORIZATION REQUIRED. Redirecting to access panel.");
    window.location.href = 'login.html';
    return;
  }

  const team = prompt("Enter your team name (leave blank for Individual):");
  if (team === null) return; // user cancelled

  try {
    const res = await fetch(`${API_URL}/${id}/register`, {
      method: 'POST',
      headers: { 
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ team })
    });
    const data = await res.json();
    if (res.ok) {
      alert("TICKET SECURED IN MAINFRAME.");
      fetchEvents();
    } else {
      alert(`ERROR: ${data.msg}`);
    }
  } catch(e) {
    alert("TRANSMISSION FAILED.");
  }
}

async function deleteEvent(id) {
  if (!confirm("Confirm deletion of this event record?")) return;

  const token = localStorage.getItem('cyber_token');
  try {
    const res = await fetch(`${API_URL}/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    if (res.ok) {
      alert("EVENT PURGED.");
      fetchEvents();
    } else {
      alert(`ERROR: ${data.msg || data.message || 'Server Error'}`);
    }
  } catch(e) {
    alert("TRANSMISSION FAILED.");
  }
}

async function deregisterEvent(id) {
  if (!confirm("Are you sure you want to unregister from this event?")) return;

  const token = localStorage.getItem('cyber_token');
  try {
    const res = await fetch(`${API_URL}/${id}/deregister`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    if (res.ok) {
      alert("SUCCESSFULLY UNREGISTERED.");
      fetchEvents();
    } else {
      alert(`ERROR: ${data.msg || 'Server Error'}`);
    }
  } catch(e) {
    alert("TRANSMISSION FAILED.");
  }
}

async function changeTeam(id) {
  const newTeam = prompt("Enter new team name:");
  if (newTeam === null) return;

  const token = localStorage.getItem('cyber_token');
  try {
    const res = await fetch(`${API_URL}/${id}/team`, {
      method: 'PUT',
      headers: { 
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ team: newTeam })
    });
    const data = await res.json();
    if (res.ok) {
      alert("TEAM UPDATED.");
      fetchEvents();
    } else {
      alert(`ERROR: ${data.msg || 'Server Error'}`);
    }
  } catch(e) {
    alert("TRANSMISSION FAILED.");
  }
}

function initCalendar() {
  const calendarEl = document.getElementById('calendar');
  calendarEl.innerHTML = ''; // reset
  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay'
    },
    events: allEventsData.flatMap(e => [
      {
        title: e.title,
        start: e.date,
        color: 'var(--primary)'
      },
      {
        title: `⚠ DEADLINE: ${e.title}`,
        start: e.registrationDeadline,
        color: 'var(--secondary)'
      }
    ])
  });
  calendar.render();
}

// Global Tab Switcher
window.switchTab = function(tabName) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.getElementById('view-list').style.display = 'none';
  document.getElementById('view-calendar').style.display = 'none';
  document.getElementById('view-analytics').style.display = 'none';

  if (tabName === 'list') {
    document.querySelectorAll('.tab')[0].classList.add('active');
    document.getElementById('view-list').style.display = 'block';
  } else if (tabName === 'calendar') {
    document.querySelectorAll('.tab')[1].classList.add('active');
    document.getElementById('view-calendar').style.display = 'block';
    
    // Calendar needs to window resize trigger to render correctly when transitioning from display:none
    window.dispatchEvent(new Event('resize'));
  } else if (tabName === 'analytics') {
    document.querySelectorAll('.tab')[2].classList.add('active');
    document.getElementById('view-analytics').style.display = 'block';
  }
}

let attendeesChartInstance = null;
let categoryChartInstance = null;

function initAnalytics() {
  const ctxAttendees = document.getElementById('attendeesChart').getContext('2d');
  const ctxCategory = document.getElementById('categoryChart').getContext('2d');

  const labelsAttendees = allEventsData.map(e => e.title);
  const dataAttendees = allEventsData.map(e => e.attendees.length);

  if (attendeesChartInstance) attendeesChartInstance.destroy();
  attendeesChartInstance = new Chart(ctxAttendees, {
    type: 'bar',
    data: {
      labels: labelsAttendees,
      datasets: [{
        label: 'Attendees',
        data: dataAttendees,
        backgroundColor: 'rgba(0, 255, 255, 0.5)',
        borderColor: '#0ff',
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true, ticks: { color: '#e0ffff', stepSize: 1 } },
        x: { ticks: { color: '#e0ffff' } }
      },
      plugins: { legend: { labels: { color: '#e0ffff' } } }
    }
  });

  const categories = {};
  allEventsData.forEach(e => {
    categories[e.category] = (categories[e.category] || 0) + 1;
  });

  if (categoryChartInstance) categoryChartInstance.destroy();
  categoryChartInstance = new Chart(ctxCategory, {
    type: 'pie',
    data: {
      labels: Object.keys(categories),
      datasets: [{
        data: Object.values(categories),
        backgroundColor: ['rgba(0, 255, 255, 0.5)', 'rgba(255, 0, 255, 0.5)', 'rgba(0, 255, 0, 0.5)', 'rgba(255, 255, 0, 0.5)'],
        borderColor: ['#0ff', '#f0f', '#0f0', '#ff0'],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { labels: { color: '#e0ffff' } } }
    }
  });
}

// Download Events as CSV
window.downloadEventsCSV = function() {
  if (allEventsData.length === 0) {
    alert("NO DATA TO DOWNLOAD.");
    return;
  }
  
  let csvContent = "data:text/csv;charset=utf-8,";
  csvContent += "Title,Category,Date,Location,Organizer,Attendees Count\n";

  allEventsData.forEach(function(ev) {
    let row = [
      `"${ev.title}"`,
      `"${ev.category}"`,
      `"${new Date(ev.date).toLocaleString()}"`,
      `"${ev.location}"`,
      `"${ev.organizer}"`,
      ev.attendees.length
    ].join(",");
    csvContent += row + "\n";
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", "campus_events_export.csv");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// QR Code Ticket Functions
window.showTicket = function(eventId) {
  const currentUserStr = localStorage.getItem('cyber_user');
  if (!currentUserStr) return;
  const currentUserId = JSON.parse(currentUserStr).id;
  
  const qrData = JSON.stringify({ eventId, userId: currentUserId });
  
  // Show modal first so container has physical dimensions in the DOM
  document.getElementById('qr-modal').style.display = 'flex';
  
  const container = document.getElementById('qrcode-container');
  container.innerHTML = ''; // clear previous
  
  // Small timeout to allow DOM to render the display:flex before drawing canvas
  setTimeout(() => {
    new QRCode(container, {
      text: qrData,
      width: 250,
      height: 250,
      colorDark : "#000000",
      colorLight : "#ffffff",
      correctLevel : QRCode.CorrectLevel.H
    });
  }, 50);
}

window.closeQrModal = function() {
  document.getElementById('qr-modal').style.display = 'none';
}

