const mongoose = require('mongoose');
const Event = require('./models/Event');
const User = require('./models/User');

const MONGO_URI = 'mongodb://127.0.0.1:27017/smartcampus';

mongoose.connect(MONGO_URI)
  .then(async () => {
    console.log('Connected to MongoDB. Fetching registered teams...\n');
    const events = await Event.find().populate('attendees.user', 'username');
    
    events.forEach(event => {
      console.log(`Event: ${event.title}`);
      if (event.attendees.length === 0) {
        console.log('  No registrations yet.');
      } else {
        event.attendees.forEach(att => {
          const username = att.user ? att.user.username : 'Unknown User';
          console.log(`  - Team: [${att.team}] | Registered by Operator: ${username} | Checked In: ${att.checkedIn ? 'Yes' : 'No'}`);
        });
      }
      console.log('--------------------------------------------------');
    });

    mongoose.connection.close();
  })
  .catch(err => {
      console.error(err);
      process.exit(1);
  });
