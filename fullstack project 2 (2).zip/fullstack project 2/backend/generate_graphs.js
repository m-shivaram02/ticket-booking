const mongoose = require('mongoose');
const Event = require('./models/Event');

const MONGO_URI = 'mongodb://127.0.0.1:27017/smartcampus';

mongoose.connect(MONGO_URI)
  .then(async () => {
    const events = await Event.find();
    
    let markdown = `# Event Analytics\n\n`;
    
    // Graph 1: Attendees per Event
    markdown += `## 1. Registration Breakdown (Attendees per Event)\n\n`;
    markdown += `\`\`\`mermaid\npie title Number of Attendees per Event\n`;
    events.forEach(e => {
        markdown += `    "${e.title}" : ${e.attendees.length}\n`;
    });
    markdown += `\`\`\`\n\n`;

    // Graph 2: Events by Category
    const categories = {};
    events.forEach(e => {
        categories[e.category] = (categories[e.category] || 0) + 1;
    });

    markdown += `## 2. Event Distribution by Category\n\n`;
    markdown += `\`\`\`mermaid\npie title Number of Events per Category\n`;
    for (const [cat, count] of Object.entries(categories)) {
        markdown += `    "${cat}" : ${count}\n`;
    }
    markdown += `\`\`\`\n\n`;

    // Output for processing
    const fs = require('fs');
    fs.writeFileSync('../event_graphs.md', markdown);
    console.log('Graphs generated in event_graphs.md');
    mongoose.connection.close();
  })
  .catch(err => {
      console.error(err);
      process.exit(1);
  });
