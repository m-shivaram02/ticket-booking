const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Event = require('./models/Event');

const MONGO_URI = 'mongodb://127.0.0.1:27017/smartcampus';

mongoose.connect(MONGO_URI)
  .then(async () => {
    console.log('MongoDB connected for seeding...');
    
    // Clear old data
    await User.deleteMany({});
    await Event.deleteMany({});
    
    // 1. Create Demo Users
    const salt = await bcrypt.genSalt(10);
    const adminPass = await bcrypt.hash('admin123', salt);
    const studentPass = await bcrypt.hash('student123', salt);
    const demoPass = await bcrypt.hash('demo123', salt);

    const admin = new User({ username: 'admin', password: adminPass, role: 'admin' });
    const student = new User({ username: 'student', password: studentPass, role: 'student' });
    const demo1 = new User({ username: 'demo1', password: demoPass, role: 'student' });
    const demo2 = new User({ username: 'demo2', password: demoPass, role: 'student' });
    
    await admin.save();
    await student.save();
    await demo1.save();
    await demo2.save();
    
    console.log('Users created: [admin:admin123], [student:student123], [demo1:demo123], [demo2:demo123]');

    // 2. Create Future Events
    const today = new Date();
    
    const event1Date = new Date(); event1Date.setDate(today.getDate() + 5);
    const event1Deadline = new Date(); event1Deadline.setDate(today.getDate() + 3);
    
    const eventOpen = new Event({
      title: 'Neon Tech Hackathon 2026',
      description: 'A 48-hour cyberpunk themed hackathon. Build the future.',
      category: 'Academic',
      date: event1Date,
      location: 'Virtual Grid 9',
      organizer: 'Synapse Club',
      registrationDeadline: event1Deadline,
      attendees: []
    });

    const event2Date = new Date(); event2Date.setDate(today.getDate() + 2);
    const event2Deadline = new Date(); event2Deadline.setDate(today.getDate() - 1); // Deadline passed

    const eventClosed = new Event({
      title: 'Synthesizer Workshop',
      description: 'Learn to build analog synths. Registrations closed.',
      category: 'Cultural',
      date: event2Date,
      location: 'Audio Lab B',
      organizer: 'Acoustics Society',
      registrationDeadline: event2Deadline,
      attendees: [student._id]
    });

    const event3Date = new Date(); event3Date.setDate(today.getDate() + 10);
    const event3Deadline = new Date(); event3Deadline.setDate(today.getDate() + 8);

    const eventCyberSec = new Event({
      title: 'Cyber-Security Summit 2026',
      description: 'Learn ethical hacking, quantum cryptography, and secure grid networks.',
      category: 'Academic',
      date: event3Date,
      location: 'Mainframe Hall',
      organizer: 'NetRunners',
      registrationDeadline: event3Deadline,
      attendees: []
    });

    const event4Date = new Date(); event4Date.setDate(today.getDate() + 15);
    const event4Deadline = new Date(); event4Deadline.setDate(today.getDate() + 12);

    const eventDJParty = new Event({
      title: 'Neon Night DJ Party',
      description: 'Experience pure synthetic waves and holographic visuals.',
      category: 'Cultural',
      date: event4Date,
      location: 'The Nexus Club',
      organizer: 'Vibe Syndicate',
      registrationDeadline: event4Deadline,
      attendees: []
    });

    const event5Date = new Date(); event5Date.setDate(today.getDate() + 20);
    const event5Deadline = new Date(); event5Deadline.setDate(today.getDate() + 18);

    const eventDroneRace = new Event({
      title: 'Drone Racing Championship',
      description: 'High-speed FPV drone racing through the campus neon circuits.',
      category: 'Sports',
      date: event5Date,
      location: 'Sector 7 Stadium',
      organizer: 'AeroTech',
      registrationDeadline: event5Deadline,
      attendees: []
    });

    await eventOpen.save();
    await eventClosed.save();
    await eventCyberSec.save();
    await eventDJParty.save();
    await eventDroneRace.save();
    console.log('Events seeded.');
    
    mongoose.connection.close();
  })
  .catch(err => console.error(err));
