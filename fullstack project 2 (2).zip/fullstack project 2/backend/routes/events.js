const express = require('express');
const router = express.Router();
const Event = require('../models/Event');
const auth = require('../middleware/auth');

// GET all upcoming events
router.get('/', async (req, res) => {
  try {
    const events = await Event.find().sort({ date: 1 }).populate('attendees.user', 'username');
    res.json(events);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// POST create a new event (protected for admin only)
router.post('/', auth, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ msg: 'Access denied. Admin only.' });
    }
    const { title, description, date, location, organizer, category, registrationDeadline } = req.body;

    const newEvent = new Event({
      title,
      description,
      date,
      location,
      organizer,
      category,
      registrationDeadline
    });

    const event = await newEvent.save();
    res.status(201).json(event);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// POST register for an event (Protected by auth)
router.post('/:id/register', auth, async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) {
      return res.status(404).json({ msg: 'Event not found' });
    }

    // Check deadline
    if (new Date() > new Date(event.registrationDeadline)) {
      return res.status(400).json({ msg: 'Registration deadline has passed' });
    }

    // Check if user is already registered
    if (event.attendees.some(a => a.user && a.user.toString() === req.user.id)) {
      return res.status(400).json({ msg: 'You are already registered for this event' });
    }

    const teamName = req.body.team ? req.body.team.trim() : 'Individual';

    // Add user to attendees
    event.attendees.push({ user: req.user.id, team: teamName || 'Individual' });
    await event.save();

    res.json({ msg: 'Successfully registered!', event });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// POST deregister from an event (Protected by auth)
router.post('/:id/deregister', auth, async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) {
      return res.status(404).json({ msg: 'Event not found' });
    }

    // Check if user is registered
    const attendeeIndex = event.attendees.findIndex(a => a.user && a.user.toString() === req.user.id);
    if (attendeeIndex === -1) {
      return res.status(400).json({ msg: 'You are not registered for this event' });
    }

    // Remove user from attendees
    event.attendees.splice(attendeeIndex, 1);
    await event.save();

    res.json({ msg: 'Successfully deregistered!', event });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// PUT update team for an event (Protected by auth)
router.put('/:id/team', auth, async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) {
      return res.status(404).json({ msg: 'Event not found' });
    }

    // Check if user is registered
    const attendee = event.attendees.find(a => a.user && a.user.toString() === req.user.id);
    if (!attendee) {
      return res.status(400).json({ msg: 'You are not registered for this event' });
    }

    const newTeamName = req.body.team ? req.body.team.trim() : 'Individual';
    attendee.team = newTeamName || 'Individual';
    await event.save();

    res.json({ msg: 'Successfully updated team!', event });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// DELETE an event (protected for admin only)
router.delete('/:id', auth, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ msg: 'Access denied. Admin only.' });
    }
    const event = await Event.findById(req.params.id);
    if (!event) {
      return res.status(404).json({ msg: 'Event not found' });
    }

    await event.deleteOne();
    res.json({ msg: 'Event removed' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

// POST checkin an attendee (protected for admin only)
router.post('/:id/checkin/:userId', auth, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ msg: 'Access denied. Admin only.' });
    }
    const event = await Event.findById(req.params.id);
    if (!event) {
      return res.status(404).json({ msg: 'Event not found' });
    }

    const attendee = event.attendees.find(a => a.user && a.user.toString() === req.params.userId);
    if (!attendee) {
      return res.status(404).json({ msg: 'User not registered for this event' });
    }

    if (attendee.checkedIn) {
      return res.status(400).json({ msg: 'User already checked in' });
    }

    attendee.checkedIn = true;
    await event.save();
    res.json({ msg: 'Check-in successful!', event });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;
