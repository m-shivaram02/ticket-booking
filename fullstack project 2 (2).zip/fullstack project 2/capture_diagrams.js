const puppeteer = require('puppeteer');
const path = require('path');

(async () => {
    console.log("Launching browser to capture diagrams...");
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    
    // Set a large viewport to ensure diagrams fit
    await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 2 });
    
    // Load the local HTML file
    const fileUrl = `file:///${path.join(__dirname, 'diagrams.html').replace(/\\/g, '/')}`;
    console.log(`Loading: ${fileUrl}`);
    await page.goto(fileUrl, { waitUntil: 'networkidle0' });
    
    // Give mermaid an extra second to fully render
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Capture Architecture Diagram
    const archElement = await page.$('#arch-container');
    if (archElement) {
        await archElement.screenshot({ path: 'Architecture_Diagram.jpg', type: 'jpeg', quality: 100 });
        console.log("Saved Architecture_Diagram.jpg");
    } else {
        console.error("Could not find Architecture Diagram element.");
    }
    
    // Capture Data Flow Diagram
    const dfdElement = await page.$('#dfd-container');
    if (dfdElement) {
        await dfdElement.screenshot({ path: 'Data_Flow_Diagram.jpg', type: 'jpeg', quality: 100 });
        console.log("Saved Data_Flow_Diagram.jpg");
    } else {
        console.error("Could not find Data Flow Diagram element.");
    }

    await browser.close();
    console.log("Finished capturing diagrams.");
})();
