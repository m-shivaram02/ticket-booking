const puppeteer = require('puppeteer');
const fs = require('fs');

(async () => {
    console.log("Capturing screenshots with authenticated session...");
    const browser = await puppeteer.launch();
    const page = await browser.newPage();
    
    // Set viewport
    await page.setViewport({ width: 1280, height: 800 });
    
    // Create directory for screenshots
    if (!fs.existsSync('screenshots')) {
        fs.mkdirSync('screenshots');
    }

    // 1. Login Page
    await page.goto('http://localhost:5000/login.html', { waitUntil: 'networkidle0' });
    await page.screenshot({ path: 'screenshots/2_Login_Page.jpg', type: 'jpeg', quality: 90 });
    console.log("Captured Login Page");

    // 2. Perform Login
    await page.type('#username', 'admin');
    await page.type('#password', 'admin123');
    await Promise.all([
        page.click('button[type="submit"]'),
        page.waitForNavigation({ waitUntil: 'networkidle0' }),
    ]);

    // 3. Home Page (Main Module Grid View)
    await page.screenshot({ path: 'screenshots/1_Home_Page_Main_Module.jpg', type: 'jpeg', quality: 90 });
    console.log("Captured Home Page (Main Module)");

    // 4. Output Page (Create Event Page)
    await page.goto('http://localhost:5000/create.html', { waitUntil: 'networkidle0' });
    await page.screenshot({ path: 'screenshots/3_Output_Page.jpg', type: 'jpeg', quality: 90 });
    console.log("Captured Output Page");

    await browser.close();
    console.log("Finished capturing screenshots.");
})();
