# Smart Campus Event Management System Diagrams

## 1. System Architecture Diagram

This diagram outlines the high-level architecture of the Smart Campus application. It follows a classic 3-tier architecture (Client, Application, Data).

```mermaid
graph TD
    %% Define Styles
    classDef frontend fill:#1e1e3f,stroke:#00f0ff,stroke-width:2px,color:#fff
    classDef backend fill:#1a1a2e,stroke:#ff003c,stroke-width:2px,color:#fff
    classDef database fill:#0f3460,stroke:#e94560,stroke-width:2px,color:#fff
    
    %% Client Tier
    subgraph Client [Client Tier (Frontend)]
        UI[Web Browser / User UI]:::frontend
        AuthStore[(Local Storage\nJWT Token)]:::frontend
    end
    
    %% Application Tier
    subgraph Server [Application Tier (Node.js & Express)]
        API[Express API Routes]:::backend
        AuthMid[JWT Auth Middleware]:::backend
        Controllers[Event & User Controllers]:::backend
    end
    
    %% Data Tier
    subgraph Database [Data Tier (MongoDB)]
        DB[(MongoDB\nsmartcampus)]:::database
        UserColl[Users Collection]:::database
        EventColl[Events Collection]:::database
    end
    
    %% Connections
    UI -- "HTTP GET/POST/PUT/DELETE\n(REST API)" --> API
    UI -- "Stores/Retrieves Token" --> AuthStore
    API -- "Verifies Token" --> AuthMid
    AuthMid -- "Passes Validated Req" --> Controllers
    Controllers -- "Mongoose ODM Queries" --> DB
    DB --- UserColl
    DB --- EventColl
```

## 2. Data Flow Diagram (DFD) - Level 1

This diagram shows how data flows through the system between external entities (Users/Admins), processes, and data stores.

```mermaid
flowchart TD
    %% Entities
    Student([Student User])
    Admin([Admin User])
    
    %% Processes
    P1((1.0\nAuthentication\nProcess))
    P2((2.0\nEvent\nManagement))
    P3((3.0\nEvent\nRegistration))
    P4((4.0\nQR Scanner &\nCheck-in))
    
    %% Data Stores
    D1[(D1: Users DB)]
    D2[(D2: Events DB)]
    
    %% Student Flows
    Student -- "Credentials (Login/Register)" --> P1
    Student -- "View Events Request" --> P2
    Student -- "Register / Deregister / Change Team" --> P3
    Student -- "Show QR Ticket" --> P4
    
    %% Admin Flows
    Admin -- "Credentials (Login)" --> P1
    Admin -- "Create/Delete Events" --> P2
    Admin -- "Scan QR & Check-in" --> P4
    
    %% Authentication Flow
    P1 -- "Verify/Store Credentials" <--> D1
    P1 -- "Issue JWT Token" --> Student
    P1 -- "Issue JWT Token" --> Admin
    
    %% Event Management Flow
    P2 -- "Fetch/Update Events" <--> D2
    
    %% Registration Flow
    P3 -- "Verify User ID & Token" --> P1
    P3 -- "Update Event Attendees" <--> D2
    
    %% Check-in Flow
    P4 -- "Validate Ticket (Event ID + User ID)" <--> D2
    P4 -- "Mark Attendee as Checked-in" --> D2
```

## How to use this file
You can view this file in VS Code or any Markdown viewer that supports Mermaid diagrams. To download this file locally, you can copy it or find it directly in your project directory at `e:\fullstack project 2\diagrams.md`.
