# Event Analytics

## 1. Registration Breakdown (Attendees per Event)

```mermaid
pie title Number of Attendees per Event
    "Neon Tech Hackathon 2026" : 1
    "Synthesizer Workshop" : 1
    "Cyber-Security Summit 2026" : 1
    "Neon Night DJ Party" : 1
    "Drone Racing Championship" : 1
```

## 2. Event Distribution by Category

```mermaid
pie title Number of Events per Category
    "Academic" : 2
    "Cultural" : 2
    "Sports" : 1
```

